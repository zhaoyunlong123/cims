create
    definer = root@localhost procedure m3()
begin
	declare a1 double;
	declare b1 double;
	declare c1 double;
	declare sum double;
	declare money int default 1000;
	
	declare a2 int;
	declare b2 int;
	declare c2 int;
	
	set a1=rand();
	set b1=rand();
	set c1=rand();
	
	set sum=a1+b1+c1;
	set a2=truncate(a1*money/sum,0);
	set b2=truncate(b1*money/sum,0);
	set c2=money-a2-b2;
	
	select a2,b2,c2;
	
end;

