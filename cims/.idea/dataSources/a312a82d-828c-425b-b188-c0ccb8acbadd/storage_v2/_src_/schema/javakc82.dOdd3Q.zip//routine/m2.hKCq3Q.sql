create
    definer = root@localhost procedure m2(IN i int, OUT o varchar(16))
begin
	case 
		when i>100 then
			set o='输入错误，请重新输入！';
		when i>=90 then
			set o='A';
		when i>=80 then 
			set o='B';
		when i>=70 then 
			set o='C';
		when i>=60 then 
			set o='D';
		when i>=0 then 
			set o='E';
		else  
			set o='输入错误，请重新输入！';
	end case;
end;

