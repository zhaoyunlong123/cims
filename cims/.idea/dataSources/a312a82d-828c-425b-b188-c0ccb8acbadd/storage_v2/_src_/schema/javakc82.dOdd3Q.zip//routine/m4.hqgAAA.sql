create
    definer = root@localhost procedure m4()
begin
	declare i int;
	declare d datetime;
	set i=0;
	set d=now();
	while i<1 do
		set i=i+1;
		insert into ding(num) value(d);
	end while;
end;

