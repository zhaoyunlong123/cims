create
    definer = root@localhost procedure tbl_F()
begin
	declare a decimal(64,0);
	declare b decimal(64,0);
	declare c decimal(64,0);
	declare i int;
	
	set a=1;
	set b=0;
	set c=0;
	set i=1;
	
	while i<=100 do 
		set c=b;
		set b=a+b;
		set a=c;
		insert into tbl_Fibonacci(id,num) value(i,b);
		set i=i+1;
	end while;
end;

