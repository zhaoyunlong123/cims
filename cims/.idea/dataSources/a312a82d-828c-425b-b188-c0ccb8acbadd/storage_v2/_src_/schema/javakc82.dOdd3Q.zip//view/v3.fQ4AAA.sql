create definer = root@localhost view v3 as
(
select `javakc82`.`user`.`userId`   AS `userId`,
       `javakc82`.`user`.`name`     AS `name`,
       `javakc82`.`user`.`ename`    AS `ename`,
       `javakc82`.`user`.`personId` AS `personId`,
       `javakc82`.`user`.`sex`      AS `sex`,
       `javakc82`.`user`.`credit`   AS `credit`,
       `javakc82`.`user`.`city`     AS `city`
from `javakc82`.`user`
where (`javakc82`.`user`.`city` = '北京'));

