create
    definer = root@localhost procedure m6()
begin
	declare a1 double;
	declare b1 double;
	declare c1 double;
	declare sum double;
	declare money int;
	
	declare a2 int;
	declare b2 int;
	declare c2 int;
	
	set a1=10;
	set b1=10;
	set c1=10;
	
	set sum=a1+b1+c1;
	
	select a1,b1,c1,sum;
	
end;

