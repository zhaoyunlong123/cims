create definer = root@localhost event e_minute on schedule
    every '1' MINUTE
        starts '2020-08-28 21:35:00'
    enable
    do
    call m4();

