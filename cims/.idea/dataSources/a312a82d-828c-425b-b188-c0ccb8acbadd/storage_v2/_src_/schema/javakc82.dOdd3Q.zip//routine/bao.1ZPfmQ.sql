create
    definer = root@localhost procedure bao(IN b_account varchar(10), IN b_money double, IN b_num int, IN b_type int)
begin
	# 声明变量
	declare i int default 0;
	# 保存红包表的id
	declare v_pid int default 0;
	# 随机数的和
	declare v_sum double default 0;
	# 备份总金额
	declare b_money2 double default 0;
	# 前b_num-1项的总金额
	declare v_sum1 double default 0;
	# 前b_num-1项
	declare b_num1 int default 0;
	# 前b_num-1项
	set b_num1=b_num-1;
	# 为每一个用户留一分钱
	set b_money2=b_money-0.01*b_num;
	# 判断红包类型
	# 普通红包
	if b_type=2 then
		
		# 插入红包表
		insert into red_packet(account,money,num,createTime,type)
								values(b_account,b_money*b_num,b_num,now(),b_type);
		
		
		
-- 		SELECT LAST_INSERT_ID()：得到刚 insert 进去记录的主键值，只适用与自增主键；
-- 		keyProperty：将查询到主键值设置到 parameterType 指定的对象的那个属性；
-- 		order：SELECT LAST_INSERT_ID() 执行顺序，相对于 insert 语句来说它的执行顺序，所以说 这个 selectKey 标签，放在前后都是可以的；
-- 		resultType：指定 SELECTLAST_INSERT_ID() 的结果类型；
		# 取到刚刚插入红包表中的主键
		select LAST_INSERT_ID() into v_pid;
		# 插入红包记录表
		while i<b_num do
			insert into Record_sheet(pid,money,ord)
			values(v_pid,b_money,i+1);
			set i=i+1;
		end while;
	
	# 随机红包
	else
		# 插入红包表
		insert into red_packet(account,money,num,createTime,type)
								values(b_account,b_money,b_num,now(),b_type);
		# 取到刚刚插入红包表中的主键
		select LAST_INSERT_ID() into v_pid;
		
		# 插入红包记录表
		while i<b_num do
			# 插入随机数
			# 先产生随机数
			# 首先定义变量 v_r  在set值  set v_r=rand(); v_sum=v_sum+v_r;

			insert into Record_sheet(pid,money,ord)
			values(v_pid,rand(),i+1);
			set i=i+1;
		end while;
		# 统计随机数的和
		select sum(money) into v_sum from Record_sheet where pid=v_pid;
		# 为红包记录中的money分钱
		update Record_sheet set money= round(money/v_sum*b_money2+0.01,2) where pid=v_pid;
		# 统计前b_num-1项的钱数
		select sum(money) into v_sum1 from (select * from Record_sheet where pid=v_pid  order by cid limit b_num1) a;
		# 计算最后一项的结果
		update Record_sheet set money=round(b_money-v_sum1,2) where pid=v_pid order by cid desc limit 1;
	end if;
end;

