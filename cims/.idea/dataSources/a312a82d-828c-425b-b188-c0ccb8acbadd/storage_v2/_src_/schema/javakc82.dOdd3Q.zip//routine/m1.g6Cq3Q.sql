create
    definer = root@localhost procedure m1(IN i int, OUT o varchar(10))
begin
	case i 
		when 0 then
			set o='星期日';
		when 1 then
			set o='星期一';
		when 2 then
			set o='星期二';
		when 3 then
			set o='星期三';
		when 4 then
			set o='星期四';
		when 5 then
			set o='星期五';
		when 6 then
			set o='星期六';
		else
			set o='输入错误！';
		end case;
	
end;

